<?php
// Data Diri
$nama = "Aura Salsabila";
$tanggal_lahir = "02 Oktober 2005";
$prodi = "Teknik Informatika";
$konsentrasi = "Teknik Informatika";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data diri Mahasiswa</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f0f8ff;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #4682b4;
            font-size: 24px;
        }
        .data-item {
            margin: 10px 0;
            font-size: 16px;
        }
        .data-item strong {
            color: #4682b4;
        }
        .kembali {
            display: block;
            text-align: center;
            margin: 20px 0 0;
            padding: 10px 20px;
            background-color: #4682b4;
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .kembali:hover {
            background-color: #5a9bd5;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Data diri Mahasiswa</h1>
    <div class="data-item">
        <strong>Nama:</strong> <span><?php echo $nama; ?></span>
    </div>
    <div class="data-item">
        <strong>Tanggal Lahir:</strong> <span><?php echo $tanggal_lahir; ?></span>
    </div>
    <div class="data-item">
        <strong>Program Studi:</strong> <span><?php echo $prodi; ?></span>
    </div>
    <div class="data-item">
        <strong>Konsentrasi:</strong> <span><?php echo $konsentrasi; ?></span>
    </div>

    <a class="kembali" href="index.php">🔙 Kembali</a>
</div>

</body>
</html>
